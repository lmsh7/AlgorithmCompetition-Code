//#pragma GCC optimize("O3")
//#pragma comment(linker, "/STACK:1024000000,1024000000")
#include<bits/stdc++.h>
using namespace std;
function<void(void)> ____ = [](){ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);};
typedef long long int LL;
const int MOD = 998244353;
const int C = 30;
string s[2], t;
LL n;
struct State{ int __cnt; string pre, suf; }f[2];
int KMP(string &text, string &pattern){
    if(pattern.size()>text.size()) return 0;
    vector<int> fail(pattern.size());
    for(int i = 1, len = 0; i < (int)pattern.size();){
        if(pattern[i]==pattern[len]) fail[i++] = ++len;
        else if(len) len = fail[len-1];
        else fail[i++] = len;
    }
    int __match_count = 0;
    for(int i = 0, j = 0; i < text.size();){
        if(text[i]==pattern[j]){
            if(j==pattern.size()-1){
                __match_count++;
                if(j) j = fail[j-1];
                else i++;
            }else i++, j++;
        }else{
            if(j) j = fail[j-1];
            else i++;
        }
    }
    return __match_count;
}
State next_state(State &sa, State &sb){
    State sta;
    auto S = sb.suf + sa.pre;
    sta.__cnt = (sa.__cnt + sb.__cnt + KMP(S,t)) % MOD;
    if(sb.pre.size()==t.size()-1) sta.pre = sb.pre;
    else{
        if(sb.pre.size()+sa.pre.size()<=t.size()-1) sta.pre = sb.pre + sa.pre;
        else sta.pre = sb.pre + sa.pre.substr(0,t.size()-1-sb.pre.size());
    }
    if(sa.suf.size()==t.size()-1) sta.suf = sa.suf;
    else{
        if(sb.suf.size()+sa.suf.size()<=t.size()-1) sta.suf = sb.suf + sa.suf;
        else sta.suf = sb.suf.substr(sb.suf.size()-(t.size()-1-sa.suf.size())) + sa.suf;
    }
    return sta;
}
template<int N>
struct Matrix{
    int mat[N][N];
    Matrix(int x = 0){ for(int i = 0; i < N; i++) for(int j = 0; j < N; j++) mat[i][j] = i==j ? x : 0; }
    Matrix operator * (Matrix rhs){
        Matrix ret(0);
        for(int i = 0; i < N; i++) for(int j = 0; j < N; j++) for(int k = 0; k < N; k++)
            ret.mat[i][j] = (ret.mat[i][j] + 1ll * mat[i][k] * rhs.mat[k][j]) % MOD;
        return ret;
    }
    Matrix operator ^ (LL b){
        Matrix ret(1);
        Matrix A; A = *this;
        while(b){
            if(b&1) ret = ret * A;
            b >>= 1;
            A = A * A;
        }
        return ret;
    }
};
using matrix = Matrix<4>;
void solve(){
    cin >> s[0] >> s[1] >> t >> n;
    f[0].__cnt = KMP(s[0],t);
    f[0].pre = s[0].substr(0,t.size()-1);
    f[0].suf = (s[0].size()>=t.size()-1) ? s[0].substr(s[0].size()-t.size()+1,t.size()-1) : s[0];
    f[1].__cnt = KMP(s[1],t);
    f[1].pre = s[1].substr(0,t.size()-1);
    f[1].suf = (s[1].size()>=t.size()-1) ? s[1].substr(s[1].size()-t.size()+1,t.size()-1) : s[1];
    if(!n) return void(cout << f[n].__cnt << endl);
    if(n<=C+10){
        for(int i = 1; i <= n - 1; i++){
            State nxt = next_state(f[0],f[1]);
            f[0] = f[1]; f[1] = nxt;
        }
        cout << f[1].__cnt << endl;
        return;
    }
    for(int i = 1; i <= C; i++){
        State nxt = next_state(f[0],f[1]);
        f[0] = f[1]; f[1] = nxt;
    }
    State nxt = next_state(f[0],f[1]);
    matrix M(0);
    M.mat[0][1] = M.mat[1][2] = M.mat[3][3] = M.mat[2][0] = M.mat[3][0] = 1;
    M.mat[1][0] = 2;
    M = M ^ (n - (C+2));
    int fa = nxt.__cnt, fb = f[1].__cnt, fc = f[0].__cnt, xy = 0;
    string S = f[1].suf + f[0].pre;
    xy = KMP(S,t);
    S = nxt.suf + f[1].pre;
    xy = (xy + KMP(S,t)) % MOD;
    cout << (1ll * fa * M.mat[0][0] % MOD + 1ll * fb * M.mat[1][0] % MOD + 1ll * fc * M.mat[2][0] % MOD + 1ll * xy * M.mat[3][0] % MOD) % MOD << endl;
}
int main(){
    #ifndef ONLINE_JUDGE
    freopen("Local.in","r",stdin);
    freopen("ans.out","w",stdout);
    #endif
    solve();
    return 0;
}