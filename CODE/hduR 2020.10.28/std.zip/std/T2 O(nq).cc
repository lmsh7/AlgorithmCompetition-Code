//#pragma GCC optimize("O3")
//#pragma comment(linker, "/STACK:1024000000,1024000000")
#include<bits/stdc++.h>
using namespace std;
function<void(void)> ____ = [](){ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);};

bool dfs(int u, vector<vector<int> > &G, vector<int> &col){
    for(int v : G[u]){
        if(col[v]!=-1){
           if(col[u]==col[v]) return false;
        }else{
            col[v] = col[u] ^ 1;
            if(!dfs(v,G,col)) return false;
        }
    }
    return true;
}
bool check(vector<pair<int,int> > &edge, int n){
    vector<vector<int> > G(n,vector<int>());
    for(auto &e : edge){
        G[e.first].emplace_back(e.second);
        G[e.second].emplace_back(e.first);
    }
    vector<int> col(n,-1);
    for(int i = 0; i < n; i++) if(col[i]==-1){
        col[i] = 0;
        if(!dfs(i,G,col)) return false;
    }
    return true;
}
void solve(){
    int n, q;
    scanf("%d %d",&n,&q);
    vector<pair<int,int> > edge;
    while(q--){
        int op;
        scanf("%d",&op);
        if(op==1){
            int x, y; scanf("%d %d",&x,&y);
            edge.emplace_back(make_pair(x-1,y-1));
            cerr << (check(edge,n) ? "YES" : "NO") << endl;
        }else edge.pop_back();
    }
}
int main(){
    #ifndef ONLINE_JUDGE
    freopen("ans.out","r",stdin);
    // freopen("ans.out","w",stdout);
    #endif
    solve();
    return 0;
}