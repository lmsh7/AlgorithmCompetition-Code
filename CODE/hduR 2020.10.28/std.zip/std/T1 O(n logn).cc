//#pragma GCC optimize("O3")
//#pragma comment(linker, "/STACK:1024000000,1024000000")
#include<bits/stdc++.h>
using namespace std;
function<void(void)> ____ = [](){ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);};

int findx(vector<int>& dsu, int x){ return x == dsu[x] ? x : dsu[x] = findx(dsu,dsu[x]); }
void solve(){
    int n; scanf("%d",&n);
    vector<int> A(n), B(n), vec;
    for(int &x : A) scanf("%d",&x), vec.emplace_back(x);
    for(int &x : B) scanf("%d",&x), vec.emplace_back(x);
    sort(begin(vec),end(vec)); vec.erase(unique(begin(vec),end(vec)),end(vec));
    for(int &x : A) x = lower_bound(begin(vec),end(vec),x) - begin(vec);
    for(int &x : B) x = lower_bound(begin(vec),end(vec),x) - begin(vec);
    vector<int> dsu(vec.size());
    for(int i = 0; i < (int)dsu.size(); i++) dsu[i] = i;
    int tot = 0;
    for(int i = 0; i < n; i++) if(findx(dsu,A[i])!=findx(dsu,B[i])) tot++, dsu[findx(dsu,A[i])] = findx(dsu,B[i]);
    cout << tot << endl;
}
int main(){
    #ifndef ONLINE_JUDGE
    freopen("Local.in","r",stdin);
    freopen("ans.out","w",stdout);
    #endif
    solve();
    return 0;
}