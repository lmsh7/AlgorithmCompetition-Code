//#pragma GCC optimize("O3")
//#pragma comment(linker, "/STACK:1024000000,1024000000")
#include<bits/stdc++.h>
using namespace std;
function<void(void)> ____ = [](){ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);};
void solve(){
    int n, q;
    scanf("%d %d",&n,&q);
    vector<int> dsu(n<<1), dep(n<<1,0);
    for(int i = 0; i < (n << 1); i++) dsu[i] = i;
    int count_of_illegal_edge = 0;
    stack<pair<int,int> > roll_back;
    auto findx = [&](int x){ while(x!=dsu[x]) x = dsu[x]; return x; };
    while(q--){
        int op; scanf("%d",&op);
        if(op==1){
            int x, y; scanf("%d %d",&x,&y); x--; y--;
            if(count_of_illegal_edge or findx(x)==findx(y)) count_of_illegal_edge++;
            else{
                int fxa = findx(x), fxb = findx(x+n);
                int fya = findx(y), fyb = findx(y+n);
                if(fxa==fyb){
                    roll_back.push(make_pair(fxa,dep[fxa]));
                    roll_back.push(make_pair(fxb,dep[fxb]));
                }else{
                    if(dep[fxa]==dep[fyb]){
                        roll_back.push(make_pair(fxa,dep[fyb]));
                        dep[fyb]++; dsu[fxa] = fyb;
                    }else{
                        if(dep[fxa]>dep[fyb]) swap(fxa,fyb);
                        roll_back.push(make_pair(fxa,dep[fyb]));
                        dsu[fxa] = fyb;
                    }
                    if(dep[fya]==dep[fxb]){
                        roll_back.push(make_pair(fya,dep[fxb]));
                        dep[fxb]++; dsu[fya] = fxb;
                    }else{
                        if(dep[fya]>dep[fxb]) swap(fya,fxb);
                        roll_back.push(make_pair(fya,dep[fxb]));
                        dsu[fya] = fxb;
                    }
                }
            }
            puts(count_of_illegal_edge ? "NO" : "YES");
        }else{
            if(count_of_illegal_edge) count_of_illegal_edge--;
            else{
                auto p = roll_back.top(); roll_back.pop();
                dep[dsu[p.first]] = p.second; dsu[p.first] = p.first;
                p = roll_back.top(); roll_back.pop();
                dep[dsu[p.first]] = p.second; dsu[p.first] = p.first;
            }
        }
    }
}
int main(){
    #ifndef ONLINE_JUDGE
    freopen("Local.in","r",stdin);
    freopen("ans.out","w",stdout);
    #endif
    solve();
    return 0;
}